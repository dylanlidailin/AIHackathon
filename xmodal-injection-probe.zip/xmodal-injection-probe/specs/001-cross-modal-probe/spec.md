# Feature Specification: Cross-Modal Injection Probe Transfer

**Feature Branch**: `001-cross-modal-probe`
**Created**: 2026-10-16
**Status**: Draft
**Input**: "Train a linear probe on a VLM's activations to detect prompt injections using text inputs only, then test whether it detects the same injections delivered as images, with controls that make a negative result interpretable."

## User Scenarios & Testing *(mandatory)*

### User Story 1 — Behavioral baseline and OCR gate (Priority: P1)

As the researcher, I run the existing injection pairs through one VLM in four conditions (clean/injected × text/image) and get (i) whether the model can read the rendered images and (ii) the attack success rate in text vs image form.

**Why this priority**: Every later result depends on it. If the model cannot read the images, no probe result about images is interpretable (Constitution I, II). The text vs image attack success comparison is also RQ1 on its own.

**Independent Test**: Run the `render`, `ocr_check`, and `generate` stages on 10 pairs with Qwen3.5-0.8B; the output is a CER table and a 2×2 attack-success table with Wilson intervals.

**Acceptance Scenarios**:

1. **Given** the pairs file and a model config, **When** the `ocr_check` stage runs, **Then** it writes per-item CER and a pass/fail verdict against the gate (median CER ≤ 0.10, n ≥ 30).
2. **Given** generations for conditions (b) and (d), **When** scoring runs, **Then** target-phrase success and repetition are reported as separate columns, with a McNemar test for text vs image on the same items.

---

### User Story 2 — Activation extraction (Priority: P1)

As the researcher, I extract the last-prompt-token hidden state at every layer for all four conditions and cache them on scratch so probes can be trained repeatedly without rerunning the model.

**Why this priority**: Probes (Stories 3–4) consume these activations; extraction is the only GPU-heavy probing step.

**Independent Test**: Run `extract` on 10 pairs; verify the cache has shape `[n_items, n_layers + 1, hidden_size]` per condition and that re-running skips completed work.

**Acceptance Scenarios**:

1. **Given** the four conditions, **When** `extract` runs, **Then** one array per condition is written with an index file mapping rows to `pair_id`.
2. **Given** a completed cache, **When** `extract` runs again with the same config hash, **Then** it exits without recomputation.

---

### User Story 3 — "Injection present" probes and layer sweep (Priority: P1)

As the researcher, I train P1 (text→text), P2 (text→image), and P3 (image→image) "injection present" probes at every layer with grouped cross-validation and get a layer-sweep plot plus a headline table.

**Why this priority**: This is the main research question (RQ2).

**Independent Test**: Run `probe --target present` on cached activations; output is `probe_present.csv` (per layer × probe × variant: AUROC with bootstrap CI, accuracy) and `layer_sweep_present.png`.

**Acceptance Scenarios**:

1. **Given** cached activations, **When** probes are trained, **Then** no `pair_id` appears in both train and test of any fold (verified by an assertion and a unit test).
2. **Given** the sweep, **When** the headline layer is reported, **Then** it was chosen by inner cross-validation on the training modality only.
3. **Given** P1 best-layer AUROC < 0.80, **When** the report stage runs, **Then** it marks downstream P2/P3 results as "not interpretable" instead of reporting them as findings.

---

### User Story 4 — "Will obey" probes (Priority: P2)

As the researcher, I train text-trained probes that predict whether the model will emit the injected target phrase, and test them on image-delivered injections (RQ3, RQ4).

**Why this priority**: Gives the mechanistic contrast with Story 3, but may be underpowered if the model rarely obeys image injections.

**Independent Test**: Run `probe --target obey`; output includes class counts per modality and a low-power flag when any class has fewer than 20 items.

**Acceptance Scenarios**:

1. **Given** generations labeled by target-phrase success, **When** obey probes are trained, **Then** repetition-only outputs are excluded from labels and counted in a separate column.

---

### User Story 5 — Report (Priority: P2)

As the researcher, I regenerate every figure and table from cached artifacts with one command, and get an outcome classification from the interpretation table in the README.

**Independent Test**: Delete `reports/`, run `report`, and get identical files.

---

### User Story 6 — Steering follow-up (Priority: P3, out of scope for first run)

If P2 transfers, use the text-derived direction to steer activations during image-injection generations and measure whether attack success drops. Not implemented in this feature; listed so the data model leaves room for it.

### Edge Cases

- The model refuses or answers both the user task and the injected task: scored by target-phrase presence only; refusals are logged.
- Rendered content exceeds the processor's maximum image size: the renderer paginates or the item is dropped and logged; never silently truncated.
- Very few image-condition obey positives: report counts and the low-power flag; do not report AUROC for classes with fewer than 5 positives.
- Qwen3.5 thinking mode emits reasoning before the answer: thinking is disabled in the chat template so outputs are comparable to the text pipeline.
- Duplicate content across pairs: deduplicate by content hash before splitting.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST load injection pairs from a JSONL file conforming to the pairs schema in `plan.md` and reject malformed rows with a clear error.
- **FR-002**: System MUST build four inputs per pair, (a)–(d), differing only in content delivery format and presence of the injection.
- **FR-003**: System MUST render content to images deterministically (bundled font, fixed size, width, margins, wrapping); identical input MUST give byte-identical PNGs.
- **FR-004**: System MUST run an OCR transcription check and report per-item CER and the gate verdict.
- **FR-005**: System MUST generate responses with greedy decoding and score target-phrase success and repetition separately.
- **FR-006**: System MUST extract the last-prompt-token hidden state at every layer for all four conditions and cache them with an index.
- **FR-007**: System MUST train P1, P2, P3 logistic-regression probes per layer using 5-fold cross-validation grouped by `pair_id`.
- **FR-008**: System MUST report AUROC with pair-level bootstrap 95% CIs as the primary metric, plus a per-modality-centered variant and a difference-of-means baseline.
- **FR-009**: System MUST write a `run_manifest.json` per run (commit, config, versions, model revision, GPU, SLURM job ID).
- **FR-010**: Every stage MUST be runnable alone via CLI, accept `--limit N`, and skip completed outputs.
- **FR-011**: System MUST reuse the repetition definition and max-new-tokens setting from the existing text-injection pipeline. [NEEDS CLARIFICATION: exact repetition rule and token limit used for the Qwen2.5-1.5B chart]
- **FR-012**: System MUST map the existing 200 test pairs (and training pairs, if used) into the pairs schema. [NEEDS CLARIFICATION: source file paths and field names of the existing dataset; whether LLMail and synthetic subsets are both included]

### Key Entities

- **Pair**: one item with a user task, a clean content string, an injected content string, the injection text, and a target phrase.
- **Condition**: one of `text_clean`, `text_injected`, `image_clean`, `image_injected`.
- **Generation**: model output for a pair × condition, with target-phrase and repetition flags.
- **Activation cache**: per-condition array of last-token hidden states over all layers.
- **Probe result**: probe type × target × layer × variant × fold → scores and metrics.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A smoke run (10 pairs, Qwen3.5-0.8B) completes all stages end-to-end in under 20 minutes on one A100.
- **SC-002**: The full run (all pairs, Qwen3.5-2B) completes in under 2 hours of wall time on one A100.
- **SC-003**: The OCR gate verdict and the 2×2 attack-success table (with Wilson CIs and McNemar p-value) are produced for the primary model.
- **SC-004**: The layer-sweep figure and headline table for P1/P2/P3 "present" probes are produced, with every P2 number shown beside P3.
- **SC-005**: Re-running `report` from cached artifacts reproduces identical tables and figures.
- **SC-006**: The final outcome is classified into one row of the README's interpretation table, with the controls that justify it.

## Assumptions

- The existing dataset provides, for each pair, a clean context, an injected context, and a target phrase (the chart's "target phrase" scoring implies this).
- One A100 (40 GB or 80 GB) is sufficient for Qwen3.5-2B inference with hidden-state output.
- A `transformers` release that supports Qwen3.5 image inputs is installable in a cloned environment; otherwise the fallback model is used (Constitution, Research Constraints).
